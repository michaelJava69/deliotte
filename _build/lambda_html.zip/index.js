"use strict";

// example lambda edge from 'generating responses' section of
// https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/lambda-examples.html#lambda-examples-generated-response-examples

const content = `
<\!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Simple Lambda@Edge Static Content Response</title>
  </head>
  <body>
    <p>Hello from Lambda@Edge!</p>
  </body>
</html>
`;

exports.handler = (event, context, callback) => {
  /*
   * Generate HTTP OK response using 200 status code with HTML body.
   */
  const response = {
    status: "200",
    statusDescription: "OK",
    headers: {
      "cache-control": [
        {
          key: "Cache-Control",
          value: "max-age=100"
        }
      ],
      "content-type": [
        {
          key: "Content-Type",
          value: "text/html"
        }
      ],
      "content-encoding": [
        {
          key: "Content-Encoding",
          value: "UTF-8"
        }
      ]
    },
    body: content
  };
  callback(null, response);
};
